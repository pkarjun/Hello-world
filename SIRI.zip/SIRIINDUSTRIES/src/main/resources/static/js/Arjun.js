var app = angular.module('app', []);
app.controller('postcontroller', function($scope, $http, $location) {
	$scope.submitForm = function(){
		var url = $location.absUrl() + "companydetails";
		
		var config = {
                headers : {
                    'Content-Type': 'application/json;charset=utf-8;'
                }
        }
		var data = {
				companyname: $scope.companyname,
				location: $scope.location,
				address: $scope.address,
				placeoccupied: $scope.placeoccupied,
				phoneno: $scope.phoneno,
				estdate: $scope.estdate
        };
		
		
		$http.post(url, data, config).then(function (response) {
			$scope.postResultMessage = "Sucessful!";	
		}, function (response) {
			$scope.postResultMessage = "Fail!";
		});
		
		 $scope.companyname="",
			 $scope.location="",
			 $scope.address="",
			 $scope.placeoccupied="",
			 $scope.phoneno="",
			 $scope.estdate=""
	}
});

app.controller('getcontroller', function($scope, $http, $location) {
	$scope.getfunction = function(){
		var url = $location.absUrl() + "getallcustomer";
		
		var config = {
                headers : {
                    'Content-Type': 'application/json;charset=utf-8;'
                }
        }
		
		$http.get(url, config).then(function (response) {
			$scope.response = response.data
		}, function (response) {
			$scope.getResultMessage = "Fail!";
		});
	}
});