package com.sirimills;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiriindustriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiriindustriesApplication.class, args);
	}
}
