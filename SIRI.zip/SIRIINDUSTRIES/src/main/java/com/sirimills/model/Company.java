package com.sirimills.model;

public class Company {

	private String companyname;
	private String location;
	private String address;
	private float placeoccupied;
	private long phoneno;
	private String estdate;
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public float getPlaceoccupied() {
		return placeoccupied;
	}
	public void setPlaceoccupied(float placeoccupied) {
		this.placeoccupied = placeoccupied;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public String getEstdate() {
		return estdate;
	}
	public void setEstdate(String estdate) {
		this.estdate = estdate;
	}
	@Override
	public String toString() {
		return "Company [companyname=" + companyname + ", location=" + location + ", address=" + address
				+ ", placeoccupied=" + placeoccupied + ", phoneno=" + phoneno + ", estdate=" + estdate + "]";
	}

	
}
